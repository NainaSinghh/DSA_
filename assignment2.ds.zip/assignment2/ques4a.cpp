#include<iostream>
using namespace std;

int main() {
  string firstname("Yashita ");
  string lastname("Aggarwal");
  string fullname = firstname + lastname;
  cout<<"My full name is "<<fullname;

  return 0;
}